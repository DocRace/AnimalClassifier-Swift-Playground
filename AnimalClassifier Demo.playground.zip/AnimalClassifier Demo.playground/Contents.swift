//: # Core ML demo! Use machine learning to predict animal species.
//: - Create ML: How we training our models
//: - Core ML: Use models in iOS Environment

import PlaygroundSupport

// Present the view controller in the Live View window
PlaygroundPage.current.liveView = AnimalClassifierViewController()
